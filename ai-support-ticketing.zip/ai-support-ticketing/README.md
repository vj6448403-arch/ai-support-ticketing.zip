# AI-Powered Customer Support Ticketing System

Salesforce Service Cloud project for a telecom support team, built with the Case object, Apex, and Agentforce.

## What is in this repo
| Part | What it does |
|---|---|
| `Case` custom fields | Service Type, SLA Due Date, AI Summary, Resolution Notes |
| `CaseTrigger` + `TicketTriggerHandler` | Auto-sets priority and SLA deadline on create/update |
| `TicketSLAService` | SLA rules: High 4h, Medium 24h, Low 72h. Network Outage is always High |
| `TicketEscalationBatch` | Escalates open tickets that passed their SLA |
| `TicketSummaryAction` | Invocable Apex used by the Agentforce agent to summarize a ticket |
| Validation rule | Cannot close a ticket without Resolution Notes |
| `Support_Agent` permission set | Field and class access for agents |
| `TicketTests` | Apex tests for all of the above |

## Deploy
```
sf org login web --alias myorg
sf project deploy start --source-dir force-app --target-org myorg
sf apex run test --class-names TicketTests --target-org myorg --result-format human
```
Load sample data: Setup > Data Import Wizard > Cases, using `data/sample_tickets.csv`.

Schedule hourly escalation (Developer Console > Execute Anonymous):
```apex
System.schedule('Hourly SLA Escalation', '0 0 * * * ?', new TicketEscalationBatch());
```

## Declarative setup (done in the org UI)
1. **Queues and Assignment Rules**: create queues Network Support, Billing Support, Activation Support. Add Case Assignment Rules by Service Type.
2. **Service Console app**: App Manager > New Lightning App > Service Console. Add the new fields to the Case page layout.
3. **Email Alerts** on escalation (optional Email-to-Case).
4. **Reports and Dashboard**: Cases by Priority, SLA Breaches (Escalated = true), Open Cases by Owner. Combine into a "Support Dashboard".
5. **Sharing**: Case OWD = Private, grant access through role hierarchy and queues.

## Agentforce setup
1. Setup > Agentforce Agents > New Agent (Service Agent).
2. Create a topic "Ticket Support" with instructions such as "Help agents understand and resolve support tickets."
3. Add action: Apex > `Summarize Support Ticket` (TicketSummaryAction).
4. Test in Agent Builder: "Summarize case 00001001".
5. Activate the agent and assign the `Support_Agent` permission set.

## Demo script (3-5 min)
Create a Network Outage ticket, show priority auto-set to High and the SLA date, ask the agent to summarize it,
try closing without notes (validation error), then show the dashboard.

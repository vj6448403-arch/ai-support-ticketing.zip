trigger CaseTrigger on Case (before insert, before update) {
    if (Trigger.isInsert) {
        TicketTriggerHandler.beforeInsert(Trigger.new);
    } else if (Trigger.isUpdate) {
        TicketTriggerHandler.beforeUpdate(Trigger.new, Trigger.oldMap);
    }
}
